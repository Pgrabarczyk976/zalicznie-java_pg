package Zaliczenie_java.Patryk;

public class Formularz {
    private int rodzajUmowy;
    private double zarobki;
    private int wiek;

    public int getRodzajUmowy() {return rodzajUmowy;}
    public double getZarobki() {return zarobki;}
    public int getWiek() {return wiek;}

    public void setRodzajUmowy(int val) {this.rodzajUmowy = val;}
    public void setZarobki(double val) {this.zarobki = val;}
    public void setWiek(int czy_ma_26_lat) {
        this.wiek = czy_ma_26_lat;
    }

    public double oblicz(){
        double wynik = 0;

        System.out.println(rodzajUmowy);
        System.out.println(zarobki);
        System.out.println(wiek);

        if (rodzajUmowy == 1) {
            wynik = zarobki - (zarobki * 0.21476);

            if (wiek > 26 && (zarobki * 12) <= 85528) {
                wynik = zarobki - (zarobki * 0.2526);
            }
        } else if (rodzajUmowy == 2) {
            wynik = zarobki;

            if (wiek > 26 && (zarobki * 12) <= 85528) {
                wynik = zarobki - (zarobki * 0.2688);
            }
        } else if (rodzajUmowy == 3) {
            wynik = zarobki - (zarobki * 0.136);
            if (wiek > 26 && (zarobki * 12) <= 85528) {
                wynik = zarobki - (zarobki * 0.22996);
            }
        }
        return wynik;
    }
}
