package Zaliczenie_java.Patryk;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import java.text.DecimalFormat;

@Controller
@RequestMapping("/strona")
public class controler {

    @GetMapping
    public String showForm(Model model) {
        model.addAttribute("formularz", new Formularz());
        return "strona";
    }

    @PostMapping
    public String oblicz(@ModelAttribute Formularz form, Model model) {
        double wynik = form.oblicz();
        String wynik_str = new DecimalFormat("#.0#").format(wynik);

        model.addAttribute("wynik", wynik_str);
        model.addAttribute("formularz", form);
        return "wynik";
    }
}
