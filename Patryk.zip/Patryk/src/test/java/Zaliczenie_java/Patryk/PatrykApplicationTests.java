package Zaliczenie_java.Patryk;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatrykApplicationTests {

	@Test
	void contextLoads() {
	}

}
